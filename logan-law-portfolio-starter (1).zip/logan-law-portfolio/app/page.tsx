export default function Home(){return (
<main style={{fontFamily:'sans-serif',maxWidth:900,margin:'40px auto',padding:20}}>
<h1>Logan James Weyforth</h1>
<p><b>Politics • Pre-Law • AI & Constitutional Law Research</b></p>
<p>Researching the intersection of constitutional law, emerging technologies, and public policy.</p>
<h2>Research Areas</h2>
<ul><li>AI & Law</li><li>Fourth Amendment</li><li>Privacy</li><li>Technology Policy</li></ul>
<h2>About</h2>
<p>I am a Politics major and Pre-Law student at Palm Beach Atlantic University focused on constitutional law and AI governance.</p>
</main>
)}