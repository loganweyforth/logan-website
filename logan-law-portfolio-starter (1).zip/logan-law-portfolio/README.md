# Logan Portfolio

This is a starter Next.js portfolio.

Create a Next.js app:

npx create-next-app@latest .

Replace the app folder with this one or ask ChatGPT to generate the full project.
